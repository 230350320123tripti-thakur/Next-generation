
const productsData = [
    {
        
        img: "https://i.postimg.cc/QCJFsdXp/derma1.jpg",
        title: "Dermatology",
        info: "Medicines on Skin Problems.",
        goto: "products/dermatology"
    },
    {
       
        img: "https://i.postimg.cc/pTNrFFrf/diabet3.jpg",
        title: "Diabetes",
        info: "Medicines on Diabetics",
        goto: "/products/diabetes"
    },
    {
       
        img: "https://i.postimg.cc/Bn6j93RK/depression.jpg",
        title: "Depression",
        info: "Medicines on Depression",
        goto: "/products/depression"
    },
    {
       
        img: "https://i.postimg.cc/SRxh2S6L/dental.jpg",
        title: "Dental",
        info: "Medicines on Dental",
        goto: "/products/dental"
    },

    {
       
        img: "https://i.postimg.cc/C1j1HxnW/Fracture.jpg",
        title: "Fracture",
        info: "Medicines on Fracture",
        goto: "/products/fracture"
    },
    {
        
        img: "https://i.postimg.cc/tRNJs7j6/womens.jpg",
        title: "Women's Care",
        info: "Medicines Women's Care",
        goto: "/products/women's Care"
    },

    {
       
        img: "https://i.postimg.cc/RC76wXcN/bloodpressure.jpg",
        title: "Blood Pressure",
        info: "Medicines on Blood Pressure",
        goto: "/products/bloodPressure"
    }
]

module.exports = productsData;
